from django.urls import path
# from account import views
# urlpatterns = [
#     path('hello/', views.hello, name="hey"),
# ]
